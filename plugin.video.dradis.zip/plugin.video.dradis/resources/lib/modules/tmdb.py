
import xbmc
import xbmcgui
import xbmcplugin
import sys
from urllib.parse import urlencode, quote_plus
from json import loads
from resources.lib.modules import control, client
from resources.lib.modules.control import setting as getSetting

def search_tmdb(term):
    try:
        api_key = getSetting('tmdb.api.key')
        url = f"https://api.themoviedb.org/3/search/multi?query={quote_plus(term)}&include_adult=false&language=es-ES&api_key={api_key}"
        response = client.request(url)
        if not response:
            return []

        results = loads(response).get('results', [])

        final_results = []
        for r in results:
            media_type = r.get('media_type')
            if media_type not in ['movie', 'tv']:
                continue

            title = r.get('title') if media_type == 'movie' else r.get('name')
            year = (r.get('release_date') or r.get('first_air_date') or '')[:4]
            label_tag = '[COLOR gold][Película][/COLOR]' if media_type == 'movie' else '[COLOR lightblue][Serie][/COLOR]'
            poster = f"https://image.tmdb.org/t/p/w500{r['poster_path']}" if r.get('poster_path') else 'DefaultVideo.png'
            fanart = f"https://image.tmdb.org/t/p/original{r['backdrop_path']}" if r.get('backdrop_path') else control.addonFanart()

            final_results.append({
                'title': f"{label_tag} {title} ({year})",
                'url': f"plugin://{control.addonId()}/?action=play&name={quote_plus(title)}",
                'icon': poster,
                'fanart': fanart
            })

        return final_results

    except Exception as e:
        from resources.lib.modules import log_utils
        log_utils.log(f"TMDb search error: {e}", level='error')
        return []